const piedavajumi = [
    { valsts: "Došanās uz Ņujorku, autobusu-gājēju ekskursija pilsētā. Ņujorka (New York City) - pasaules nozīmes megapole un lielākā ASV pilsētā.", cena: 1200, attels: "7.jpg" },
    { valsts: "Losandželosa - saukta arī par Eņģeļu pilsētu vai saīsināti par L.A., ir pilsēta ASV dienvidrietumos pie Klusā okeāna.", cena: 1500, attels: "losandz.jpg" },
    { valsts: "Maiami ir viena no dārgākajām, krāšņākajām un populārākajām pilsētām pasaulē. Un viena no Amerikas daļām, kurās angliski nerunā.", cena: 1800, attels: "majami.jpg" },
    { valsts: "Čikāga ir pazīstama ar savu slaveno arhitektūru, bagāto kultūras un mākslas ainas, izcilu izklaides piedāvājumu un daudzveidīgo ēdienu.", cena: 2000, attels: "12 (1).jpg" }
];

function raditPiedavajumus(filtrEtiePiedavajumi = piedavajumi) {
    const piedavajumuKonteiners = document.getElementById("piedavajumi");
    piedavajumuKonteiners.innerHTML = "";

    filtrEtiePiedavajumi.forEach(piedavajums => {
        const piedavajumaBloks = document.createElement("div");
        piedavajumaBloks.classList.add("piedavajuma-kartite");
        piedavajumaBloks.innerHTML = `
            <img src="${piedavajums.attels}" alt="${piedavajums.valsts}">
            <h3>${piedavajums.valsts}</h3>
            <p>Cena: ${piedavajums.cena}$</p>
        `;
        piedavajumuKonteiners.appendChild(piedavajumaBloks);
    });
}
// Cenu filtrs
document.getElementById("cenu-filtrs").addEventListener("input", function () {
    const maxCena = parseInt(this.value);
    document.getElementById("cenas-vertiba").textContent = `${maxCena}$`;
    const filtrEtiePiedavajumi = piedavajumi.filter(piedavajums => piedavajums.cena <= maxCena);
    raditPiedavajumus(filtrEtiePiedavajumi);
});
raditPiedavajumus();

const spelesPiedavajumi = [
    { valsts: "Maiami", cena: 1800, attels: "majami.jpg" },
    { valsts: "Parīze", cena: 2500, attels: "paris.jpg" },
    { valsts: "Roma", cena: 2700, attels: "rome.jpg" },
    { valsts: "Berlīne", cena: 2000, attels: "berlin.jpg" }
];

let meginajumi = 0;
let maxMeginajumi = 3;
let pasreizejaisPiedavajumaIndex = 0;

function sakSpele() {
    if (meginajumi < maxMeginajumi) {
        const izveletsPiedavajums = spelesPiedavajumi[pasreizejaisPiedavajumaIndex];
        document.getElementById("minejuma-teksts").textContent = `Uzminiet, cik varētu maksāt ceļojums uz ${izveletsPiedavajums.valsts}!`;
        document.getElementById("meginajumu-teksts").textContent = `Atlikušie mēģinājumi: ${maxMeginajumi - meginajumi}`;
        document.getElementById("speles-rezultats").textContent = "";
        document.getElementById("pareiza-valsts-attels").classList.add("paslepjams");
        document.getElementById("minejuma-ievade").value = "";
    } else {
        document.getElementById("minejuma-teksts").textContent = "Visas iespējas ir izsmeltas!";
        document.getElementById("speles-rezultats").textContent = "Diemžēl neizdevās uzminēt ceļojumu cenas.";
        document.getElementById("parbaudit-cenu").disabled = true;
        document.getElementById("atkartot").classList.add("paslepjams");
    }
}
// Funkcija nodrošina lietotāja minējumu, kad lietotajs nospied pogu
document.getElementById("parbaudit-cenu").addEventListener("click", function () {
    if (meginajumi >= maxMeginajumi) return;
    const minejums = parseInt(document.getElementById("minejuma-ievade").value);
    const pareizaisPiedavajums = spelesPiedavajumi[pasreizejaisPiedavajumaIndex];
    if (isNaN(minejums)) {
        document.getElementById("speles-rezultats").textContent = "Lūdzu, ievadiet derīgu summu!";
        return;
    }

    let rezultats;
    if (minejums === pareizaisPiedavajums.cena) {
        rezultats = `Pareizi! Ceļojums uz ${pareizaisPiedavajums.valsts} maksā ${pareizaisPiedavajums.cena}$.`;
        document.getElementById("parbaudit-cenu").disabled = true;
    } else {
        rezultats = `Nepareizi! Pareizā cena bija ${pareizaisPiedavajums.cena}$.`;
        document.getElementById("atkartot").classList.remove("paslepjams");
        document.getElementById("parbaudit-cenu").disabled = true;
    }
    document.getElementById("speles-rezultats").textContent = rezultats;
    document.getElementById("pareiza-valsts-attels").src = pareizaisPiedavajums.attels;
    document.getElementById("pareiza-valsts-attels").classList.remove("paslepjams");
});

document.getElementById("atkartot").addEventListener("click", function () { // Nospiežot "Atkārtot", lietotājam tiek dota nākamā iespēja pameiģināt atminēt cenu
    meginajumi++;

    if (meginajumi >= maxMeginajumi) {
        document.getElementById("minejuma-teksts").textContent = "Visas iespējas ir izsmeltas!";
        document.getElementById("meginajumu-teksts").textContent = "";
        document.getElementById("speles-rezultats").textContent += " Spēle ir beigusies.";
        document.getElementById("parbaudit-cenu").disabled = true;
        document.getElementById("atkartot").classList.add("paslepjams");
        return;
    }
    pasreizejaisPiedavajumaIndex = (pasreizejaisPiedavajumaIndex + 1) % spelesPiedavajumi.length;
    document.getElementById("atkartot").classList.add("paslepjams");
    document.getElementById("parbaudit-cenu").disabled = false;
    sakSpele();
});

//Noteikumu poga
document.getElementById("noteikumapoga").addEventListener("click", function () {
    document.getElementById("speles-noteikumi").classList.toggle("paslepjams");//classList.toggle ieslēdz vai izslēdz CSS uzrakstito elemntu "paslepjams".  https://www.w3schools.com/jsref/tryit.asp?filename=tryjsref_element_classlist_toggle
});
document.getElementById("aizvert-noteikumus").addEventListener("click", function () {
    document.getElementById("speles-noteikumi").classList.add("paslepjams");
});

sakSpele();

let izveletaValuta = "USD";

const kursi = {
  PLN: 4.204,
  EUR: 0.918,
  GBP: 0.786,
};

function izveletiesValutu(valuta) {
  izveletaValuta = valuta;
  document.getElementById("valutaPoga").textContent = `${valuta} ▼`;
}
function konvertet() {
  const summa = parseFloat(document.getElementById("summa").value); //"parseFloat" pārveido string uz decimāldaļu
  const rezultats = document.getElementById("rezultats");

  if (isNaN(summa) || summa <= 0) {
    rezultats.textContent = "Lūdzu, ievadiet derīgu pozitīvu summu!";
    return;
  }
  if (!kursi[izveletaValuta]) {
    rezultats.textContent = "Izvēlieties vienu no piedāvātajām valūtām!";
    return;
  }
  const konvertets = summa * kursi[izveletaValuta];
  rezultats.textContent = `Rezultāts: ${konvertets.toFixed(2)} ${izveletaValuta}`; //toFixed(2)  noapaļo skaitli līdz 2 zīmēm aiz komata 
}
// Ka funkcijas paraugu ņēmu informāciju šeit: https://codepen.io/DeyJordan/pen/GRXaQmR
function atjaunotLaiku() {
  const tagad = new Date();
  const opcijas = {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  };
  document.getElementById('datums-laiks').textContent = tagad.toLocaleString('lv-LV', opcijas);
}

setInterval(atjaunotLaiku, 1000);
atjaunotLaiku();
